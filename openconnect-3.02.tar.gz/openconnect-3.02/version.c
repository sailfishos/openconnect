char openconnect_version[] = "v3.02";
